/* Name: Felix Liu
 Course: CNT 4714 – Summer 2024 – Project Three
 Assignment title: A Three-Tier Distributed Web-Based Application
 Date: August 1, 2024
*/

import com.mysql.cj.jdbc.MysqlDataSource;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;

@WebServlet("/ExecuteSQLServlet")
public class RootServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String sqlCommand = request.getParameter("sqlCommand");

        String resultHtml = executeSqlCommand(sqlCommand, getServletContext().getRealPath("/WEB-INF/lib/root.properties"));

        request.setAttribute("sqlCommand", sqlCommand);
        request.setAttribute("sqlResult", resultHtml);
        request.getRequestDispatcher("/roothome.jsp").forward(request, response);
    }

    private String executeSqlCommand(String sqlCommand, String propertiesPath) {
        Properties dbProperties = new Properties();
        try (FileInputStream propFile = new FileInputStream(propertiesPath)) {
            dbProperties.load(propFile);
        } catch (IOException e) {
            return buildErrorHtml("Failed to load database properties", e.getMessage(), sqlCommand);
        }

        MysqlDataSource dataSource = new MysqlDataSource();
        dataSource.setURL(dbProperties.getProperty("MYSQL_DB_URL"));
        dataSource.setUser(dbProperties.getProperty("MYSQL_DB_USERNAME"));
        dataSource.setPassword(dbProperties.getProperty("MYSQL_DB_PASSWORD"));

        try (Connection connection = dataSource.getConnection();
             PreparedStatement statement = connection.prepareStatement(sqlCommand)) {

            boolean isSelectQuery = sqlCommand.trim().toLowerCase().startsWith("select");
            if (isSelectQuery) {
                return executeSelectQuery(statement);
            } else {
                return executeUpdateQuery(statement, sqlCommand, connection);
            }
        } catch (SQLException e) {
            return buildErrorHtml("Error executing SQL command", e.getMessage(), sqlCommand);
        }
    }

    private String executeSelectQuery(PreparedStatement statement) throws SQLException {
        StringBuilder resultBuilder = new StringBuilder("<table border='1'>");
        try (ResultSet resultSet = statement.executeQuery()) {
            int columnCount = resultSet.getMetaData().getColumnCount();
            resultBuilder.append("<tr>");
            for (int i = 1; i <= columnCount; i++) {
                resultBuilder.append("<th>").append(resultSet.getMetaData().getColumnName(i)).append("</th>");
            }
            resultBuilder.append("</tr>");
            while (resultSet.next()) {
                resultBuilder.append("<tr>");
                for (int i = 1; i <= columnCount; i++) {
                    resultBuilder.append("<td>").append(resultSet.getString(i)).append("</td>");
                }
                resultBuilder.append("</tr>");
            }
        }
        resultBuilder.append("</table>");
        return resultBuilder.toString();
    }

    private String executeUpdateQuery(PreparedStatement statement, String sqlCommand, Connection connection) throws SQLException {
        StringBuilder resultBuilder = new StringBuilder();
        int affectedRows = statement.executeUpdate();
        resultBuilder.append("<p>Command executed successfully. Affected rows: ").append(affectedRows).append("</p>");

        if (shouldApplyBusinessLogic(sqlCommand)) {
            applyBusinessLogic(connection, resultBuilder);
        } else {
            resultBuilder.append("<p>Business Logic Not Detected</p>");
        }
        return resultBuilder.toString();
    }

    private boolean shouldApplyBusinessLogic(String sqlCommand) {
        String trimmedCommand = sqlCommand.trim().toLowerCase();
        return trimmedCommand.contains("shipments") && 
               (trimmedCommand.startsWith("insert") || trimmedCommand.startsWith("update"));
    }

    private void applyBusinessLogic(Connection connection, StringBuilder resultBuilder) throws SQLException {
        String updateStatusSql = "UPDATE suppliers SET status = status + 5 WHERE snum IN (SELECT snum FROM shipments WHERE quantity >= 100)";
        try (PreparedStatement updateStatement = connection.prepareStatement(updateStatusSql)) {
            int updatedRows = updateStatement.executeUpdate();
            if (updatedRows > 0) {
                resultBuilder.append("<p>Business Logic Detected - Updating Supplier Status</p>");
                resultBuilder.append("<p>Business Logic updated ").append(updatedRows).append(" supplier status marks.</p>");
            } else {
                resultBuilder.append("<p>Business Logic Detected - No Supplier Status Updates</p>");
            }
        }
    }

    private String buildErrorHtml(String errorTitle, String errorMessage, String sqlCommand) {
        return new StringBuilder()
                .append("ERROR: ").append(errorTitle).append("<br>")
                .append("MESSAGE: ").append(errorMessage).append("<br>")
                .append("COMMAND: ").append(sqlCommand)
                .toString();
    }
}
