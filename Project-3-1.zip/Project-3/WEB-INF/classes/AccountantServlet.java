/* Name: Felix Liu
 Course: CNT 4714 – Summer 2024 – Project Three
 Assignment title: A Three-Tier Distributed Web-Based Application
 Date: August 1, 2024
*/
import com.mysql.cj.jdbc.MysqlDataSource;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.Properties;

@WebServlet("/AccountantServlet")
public class AccountantServlet extends HttpServlet {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Connection getConnection() throws IOException, SQLException {
        Properties dbProperties = new Properties();
        try (FileInputStream input = new FileInputStream(
                getServletContext().getRealPath("/WEB-INF/lib/properties/theaccountant.properties"))) {
            dbProperties.load(input);
        }

        MysqlDataSource dataSource = new MysqlDataSource();
        dataSource.setURL(dbProperties.getProperty("MYSQL_DB_URL"));
        dataSource.setUser(dbProperties.getProperty("MYSQL_DB_USERNAME"));
        dataSource.setPassword(dbProperties.getProperty("MYSQL_DB_PASSWORD"));

        return dataSource.getConnection();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String cmdValue = request.getParameter("cmd");
        String sqlCommand = getSqlCommand(cmdValue);
        String resultMessage;

        response.setContentType("text/html");
        try (PrintWriter out = response.getWriter()) {
            try (Connection connection = getConnection()) {
                resultMessage = executeSqlCommand(connection, sqlCommand);
            } catch (SQLException e) {
                resultMessage = generateErrorMessage(e);
            }
            out.print(resultMessage);
        }
    }

    private String getSqlCommand(String cmdValue) {
        if ("sumPartsWeight".equals(cmdValue)) {
            return "{call Get_The_Sum_Of_All_Parts_Weights()}";
        } else if ("maxSupplierStatus".equals(cmdValue)) {
            return "{call Get_The_Maximum_Status_Of_All_Suppliers()}";
        } else if ("totalShipments".equals(cmdValue)) {
            return "{call Get_The_Total_Number_Of_Shipments()}";
        } else if ("mostWorkersJob".equals(cmdValue)) {
            return "{call Get_The_Name_Of_The_Job_With_The_Most_Workers()}";
        } else if ("listSuppliers".equals(cmdValue)) {
            return "{call List_The_Name_And_Status_Of_All_Suppliers()}";
        } else {
            return "{call ERROR()}";
        }
    }

    private String executeSqlCommand(Connection connection, String sqlCommand) throws SQLException {
        try (CallableStatement statement = connection.prepareCall(sqlCommand)) {
            boolean hasResultSet = statement.execute();
            if (hasResultSet) {
                try (ResultSet resultSet = statement.getResultSet()) {
                    return formatResultSetToHtml(resultSet);
                }
            } else {
                return "<p>No data found or error executing RPC!</p>";
            }
        }
    }

    private String generateErrorMessage(SQLException e) {
        return "<div style='color: red;'><strong>Error executing the SQL statement:</strong><br>" + e.getMessage() + "</div>";
    }

    private String formatResultSetToHtml(ResultSet rs) throws SQLException {
        StringBuilder htmlBuilder = new StringBuilder("<table border='1'>");
        ResultSetMetaData metaData = rs.getMetaData();
        int columnCount = metaData.getColumnCount();

        // Add table headers
        htmlBuilder.append("<tr>");
        for (int i = 1; i <= columnCount; i++) {
            htmlBuilder.append("<th>").append(metaData.getColumnName(i)).append("</th>");
        }
        htmlBuilder.append("</tr>");

        // Add table rows
        while (rs.next()) {
            htmlBuilder.append("<tr>");
            for (int i = 1; i <= columnCount; i++) {
                htmlBuilder.append("<td>").append(rs.getString(i)).append("</td>");
            }
            htmlBuilder.append("</tr>");
        }
        htmlBuilder.append("</table>");
        return htmlBuilder.toString();
    }
}
