/* Name: Felix Liu
 Course: CNT 4714 – Summer 2024 – Project Three
 Assignment title: A Three-Tier Distributed Web-Based Application
 Date: August 1, 2024
*/
import com.mysql.cj.jdbc.MysqlDataSource;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Properties;

@WebServlet("/DataEntryServlet")
public class DataEntryServlet extends HttpServlet {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String table = request.getParameter("table");
        Properties properties = new Properties();
        FileInputStream filein = null;
        MysqlDataSource dataSource = null;
        Connection connection = null;
        PreparedStatement statement = null;
        String sql = "";
        boolean businessLogicTriggered = false;
        StringBuilder resultMessage = new StringBuilder();

        try {
            filein = new FileInputStream(
                    getServletContext().getRealPath("/WEB-INF/lib/dataentryuser.properties"));
            properties.load(filein);

            dataSource = new MysqlDataSource();
            dataSource.setURL(properties.getProperty("MYSQL_DB_URL"));
            dataSource.setUser(properties.getProperty("MYSQL_DB_USERNAME"));
            dataSource.setPassword(properties.getProperty("MYSQL_DB_PASSWORD"));

            connection = dataSource.getConnection();

            switch (table) {
                case "suppliers":
                    sql = "INSERT INTO suppliers (snum, sname, status, city) VALUES (?, ?, ?, ?)";
                    statement = connection.prepareStatement(sql);
                    statement.setString(1, request.getParameter("snum"));
                    statement.setString(2, request.getParameter("sname"));
                    statement.setInt(3, Integer.parseInt(request.getParameter("status")));
                    statement.setString(4, request.getParameter("city"));
                    break;
                case "parts":
                    sql = "INSERT INTO parts (pnum, pname, color, weight, city) VALUES (?, ?, ?, ?, ?)";
                    statement = connection.prepareStatement(sql);
                    statement.setString(1, request.getParameter("pnum"));
                    statement.setString(2, request.getParameter("pname"));
                    statement.setString(3, request.getParameter("color"));
                    statement.setInt(4, Integer.parseInt(request.getParameter("weight")));
                    statement.setString(5, request.getParameter("city"));
                    break;
                case "jobs":
                    sql = "INSERT INTO jobs (jnum, jname, numworkers, city) VALUES (?, ?, ?, ?)";
                    statement = connection.prepareStatement(sql);
                    statement.setString(1, request.getParameter("jnum"));
                    statement.setString(2, request.getParameter("jname"));
                    statement.setInt(3, Integer.parseInt(request.getParameter("numworkers")));
                    statement.setString(4, request.getParameter("city"));
                    break;
                case "shipments":
                    sql = "INSERT INTO shipments (snum, pnum, jnum, quantity) VALUES (?, ?, ?, ?)";
                    statement = connection.prepareStatement(sql);
                    statement.setString(1, request.getParameter("snum"));
                    statement.setString(2, request.getParameter("pnum"));
                    statement.setString(3, request.getParameter("jnum"));
                    statement.setInt(4, Integer.parseInt(request.getParameter("quantity")));
                    businessLogicTriggered = Integer.parseInt(request.getParameter("quantity")) >= 100;
                    break;
            }

            int rowsAffected = statement.executeUpdate();

            resultMessage.append("<div style='color: blue; border: 2px solid blue; padding: 10px;'>");
            resultMessage.append("<p>New ").append(table).append(" record: (");

            // Append the values entered for the new record
            switch (table) {
                case "suppliers":
                    resultMessage.append(request.getParameter("snum")).append(", ").append(request.getParameter("sname")).append(", ")
                            .append(request.getParameter("status")).append(", ").append(request.getParameter("city"));
                    break;
                case "parts":
                    resultMessage.append(request.getParameter("pnum")).append(", ").append(request.getParameter("pname")).append(", ")
                            .append(request.getParameter("color")).append(", ").append(request.getParameter("weight")).append(", ")
                            .append(request.getParameter("city"));
                    break;
                case "jobs":
                    resultMessage.append(request.getParameter("jnum")).append(", ").append(request.getParameter("jname")).append(", ")
                            .append(request.getParameter("numworkers")).append(", ").append(request.getParameter("city"));
                    break;
                case "shipments":
                    resultMessage.append(request.getParameter("snum")).append(", ").append(request.getParameter("pnum")).append(", ")
                            .append(request.getParameter("jnum")).append(", ").append(request.getParameter("quantity"));
                    break;
            }

            resultMessage.append(") - successfully entered into database.</p>");

            // Business logic message
            if (businessLogicTriggered) {
                resultMessage.append("<p>Business Logic Detected - Updating Supplier Status</p>");
                String updateStatusSql = "UPDATE suppliers SET status = status + 5 WHERE snum IN (SELECT snum FROM shipments WHERE quantity >= 100)";
                statement = connection.prepareStatement(updateStatusSql);
                int suppliersUpdated = statement.executeUpdate();
                if (suppliersUpdated > 0) {
                    resultMessage.append("<p>Business Logic updated ").append(suppliersUpdated).append(" supplier status marks.</p>");
                } else {
                    resultMessage.append("<p>Business Logic Detected - No Supplier Status Updates</p>");
                }
            } else {
                resultMessage.append("<p>Business Logic Not Detected</p>");
            }

            resultMessage.append("</div>");
        } catch (SQLException e) {
            response.setStatus(HttpServletResponse.SC_OK);
            resultMessage.append("<div style='color: red; border: 2px solid red; padding: 10px;'>");
            resultMessage.append("<p>Error executing SQL command:</p>");
            resultMessage.append("<p><b>").append(e.getMessage()).append("</b></p>");
            resultMessage.append("<p><b>Command:</b> ").append(sql).append("</p>");
            resultMessage.append("</div>");
        } finally {
            try {
                if (statement != null)
                    statement.close();
                if (connection != null)
                    connection.close();
                if (filein != null)
                    filein.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        request.setAttribute("resultMessage", resultMessage.toString());
        request.getRequestDispatcher("/dataentryuser.jsp").forward(request, response);
    }
}
