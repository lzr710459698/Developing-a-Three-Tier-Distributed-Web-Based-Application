/* Name: Felix Liu
 Course: CNT 4714 – Summer 2024 – Project Three
 Assignment title: A Three-Tier Distributed Web-Based Application
 Date: August 1, 2024
*/
import com.mysql.cj.jdbc.MysqlDataSource;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;

@WebServlet("/Authenticate")
public class AuthenticateServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        boolean isValidUser = authenticateUser(username, password, getServletContext().getRealPath("/WEB-INF/lib/systemapp.properties"));

        if (isValidUser) {
            redirectToUserHome(username, response);
        } else {
            redirectToErrorPage(response);
        }
    }

    private boolean authenticateUser(String username, String password, String propertiesPath) {
        Properties dbProperties = new Properties();
        try (FileInputStream propFile = new FileInputStream(propertiesPath)) {
            dbProperties.load(propFile);
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }

        MysqlDataSource dataSource = new MysqlDataSource();
        dataSource.setURL(dbProperties.getProperty("MYSQL_DB_URL"));
        dataSource.setUser(dbProperties.getProperty("MYSQL_DB_USERNAME"));
        dataSource.setPassword(dbProperties.getProperty("MYSQL_DB_PASSWORD"));

        try (Connection connection = dataSource.getConnection();
             PreparedStatement statement = connection.prepareStatement("SELECT login_password FROM usercredentials WHERE login_username = ?")) {

            statement.setString(1, username);
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    String storedPassword = resultSet.getString("login_password");
                    return storedPassword.equals(password);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    private void redirectToUserHome(String username, HttpServletResponse response) throws IOException {
        switch (username) {
            case "root":
                response.sendRedirect("roothome.jsp");
                break;
            case "client":
                response.sendRedirect("clienthome.jsp");
                break;
            case "dataentryuser":
                response.sendRedirect("dataentryuser.jsp");
                break;
            case "theaccountant":
                response.sendRedirect("accountant.jsp");
                break;
            default:
                response.getWriter().println("<p>Authentication Successful, but no specific page to redirect!</p>");
        }
    }

    private void redirectToErrorPage(HttpServletResponse response) throws IOException {
        response.sendRedirect("errorpage.html");
    }
}
